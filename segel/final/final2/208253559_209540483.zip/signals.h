//
// Created by DELL on 10/04/2023.
//

#ifndef HW1WET_SIGNALS_H
#define HW1WET_SIGNALS_H
#define SMALLEST_SIG_NUM 0
#define BIGGEST_SIG_NUM 31

void ctrlCHandler(int sig_num);
void ctrlZHandler(int sig_num);
void alarmHandler(int sig_num);

#endif //HW1WET_SIGNALS_H
